#include "Geometry.h"

using namespace glm;

Geometry::Geometry(geometryType geomType) :
    type_(geomType)
{
}

Geometry::~Geometry()
{
    vertices_.clear();
    normals_.clear();
    colors_.clear();
    indices_.clear();
}

Intersection Geometry::intersect(const mat4 &T, Ray ray_world) const
{
    // The input ray here is in WORLD-space. It may not be normalized!

    // TODO: normalize ray_world.
	ray_world.dir = normalize(ray_world.dir);
    // Transform the ray into OBJECT-LOCAL-space, for intersection calculation.
    Ray ray_local;  // TODO: COMPUTE THIS AS FOLLOWS:
    // Transform the ray by the inverse transformation to get ray_local.
    // (Remember that position = vec4(vec3, 1) while direction = vec4(vec3, 0).)
	mat4 T_inv = inverse(T);
	ray_local.orig = vec3(T_inv * vec4(ray_world.orig,1));
	ray_local.dir = vec3(T_inv * vec4(ray_world.orig + ray_world.dir, 0) - T_inv*vec4(ray_world.orig,0));

    // Compute the intersection in LOCAL-space.
    Intersection isx = intersectImpl(ray_local);
	isx.g = (Geometry *) this;
    if (isx.t != -1) {
        // Transform the local-space intersection BACK into world-space.
        //     (Note that, as long as you didn't re-normalize the ray direction
        //     earlier, `t` doesn't need to change.)
        const vec3 normal_local = isx.normal;
		
        vec3 normal_world;  // TODO: COMPUTE THIS AS FOLLOWS:
        // Inverse-transpose-transform the normal to get it back from
        // local-space to world-space. (If you were transforming a position,
        // you would just use the unmodified transform T.)
        // http://www.arcsynthesis.org/gltut/Illumination/Tut09%20Normal%20Transformation.html
		normal_world = vec3(transpose(inverse(T))*vec4(normal_local,0));
		
        isx.normal = normal_world;
		
        // TODO: You might want to do this here: make sure here that your
        // normal is pointing the right way (toward, not away from, the ray
        // origin). Instead of doing this inside intersectImpl, you can do so
        // here by just negating normal_world depending on the sign of
        //     dot(normal_world, ray_world.dir).
		
		isx.normal *= dot(normal_world, ray_world.dir) < 0 ? 1 : -1;
		isx.normal = normalize(isx.normal);
    }

    // The final output intersection data is in WORLD-space.
	/*if(isx.t>0)
	std::cout<<"Final: "<<isx.t<<endl;*/
    return isx;
}
